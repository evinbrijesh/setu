---
name: Setu
colors:
  surface: '#f8f9ff'
  surface-dim: '#d1dbec'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dfe9fa'
  surface-container-highest: '#d9e3f4'
  on-surface: '#121c28'
  on-surface-variant: '#444651'
  inverse-surface: '#27313e'
  inverse-on-surface: '#eaf1ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#5c5f60'
  on-secondary: '#ffffff'
  secondary-container: '#dee0e2'
  on-secondary-container: '#606365'
  tertiary: '#003122'
  on-tertiary: '#ffffff'
  tertiary-container: '#004a35'
  on-tertiary-container: '#70bb9c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#e1e2e4'
  secondary-fixed-dim: '#c5c6c8'
  on-secondary-fixed: '#191c1e'
  on-secondary-fixed-variant: '#444749'
  tertiary-fixed: '#a6f2d1'
  tertiary-fixed-dim: '#8bd6b6'
  on-tertiary-fixed: '#002116'
  on-tertiary-fixed-variant: '#00513b'
  background: '#f8f9ff'
  on-background: '#121c28'
  surface-variant: '#d9e3f4'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  multilingual-subtext:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  unit: 8px
  container-padding: 24px
  gutter: 16px
  stack-gap: 32px
  section-margin: 64px
---

## Brand & Style
The design system is built on the philosophy of "Sovereign Simplicity." It serves as a digital bridge between the citizen and the state, requiring a persona that is professional, confident, and profoundly reassuring. Unlike the aggressive speed of fintech or the cluttered complexity of traditional government portals, this system prioritizes a calm, meditative pace.

The aesthetic direction is **Refined Institutionalism**. It avoids "startup-generic" tropes by using substantial white space and a grounded, structured layout. The visual language evokes the stability of a public monument—permanent, accessible, and dignified—while the interaction model remains fluid and responsive to voice.

**Target Emotional Response:**
- **Dignity:** Users should feel respected by the clarity and lack of "dark patterns."
- **Clarity:** Every interface element must be immediately understood, even by those with low digital literacy.
- **Trust:** The "government-adjacent" feel is achieved through conservative color application and a lack of decorative flourishes.

## Colors
The palette is intentionally limited to maintain focus and reduce cognitive load. 

- **Primary (Deep Indigo):** Used exclusively for high-priority actions, key navigation states, and the primary brand presence. It provides the "institutional" weight necessary for a civic agent.
- **Surface (Soft Gray):** Used for background layering and secondary containers to soften the contrast against the pure white page background.
- **Accent (State Green):** A tertiary deep green (#065F46) is used sparingly for success states and verified statuses, aligning with traditional official document signaling.
- **Functional Grays:** Text and iconography use a scale of grays rather than pure black to prevent visual fatigue while maintaining high accessibility ratios.

## Typography
The typography system uses **Inter** for its exceptional legibility and neutral, systematic character. To ensure accessibility across diverse demographics, font sizes are larger than standard web defaults.

**Multilingual Strategy:**
Since the agent supports Hindi, Tamil, and English, the line-heights are set generously to accommodate the varying heights of Indic scripts without overlapping. When displaying translations, the secondary language should be placed immediately below the primary language in a slightly lighter weight or smaller size (`multilingual-subtext`) to provide immediate context.

**Hierarchy Rules:**
- Use `headline-xl` only for the primary greeting or current task state.
- `body-lg` is the default for AI-generated responses to ensure ease of reading for elderly users.

## Layout & Spacing
The layout follows a **Fluid Grid** with strict vertical rhythm based on an 8px base unit. 

- **Mobile First:** The core experience is optimized for single-column mobile use, where the primary agent interaction sits at the bottom third of the screen.
- **Generous Whitespace:** Components are separated by a minimum of `stack-gap` (32px) to prevent the UI from feeling cramped or overwhelming.
- **Safe Margins:** A `container-padding` of 24px ensures that text never feels squeezed against the edges of the device, reinforcing the "calm" brand attribute.
- **Desktop Reflow:** On larger screens, the content remains centered in a maximum 720px readable well to prevent line lengths from becoming too long for easy reading.

## Elevation & Depth
Elevation is handled through **Tonal Layers** rather than heavy shadows. This maintains a clean, modern appearance that feels integrated rather than floating.

- **Level 0 (Base):** Pure White (#FFFFFF).
- **Level 1 (Surface):** Soft Gray (#F3F4F6) used for the main interaction cards or list containers.
- **Active State:** A very soft, high-diffusion shadow (0px 4px 20px rgba(0,0,0,0.04)) is applied only to the primary input card to signify it is currently "live" or being interacted with.
- **The Voice Button:** This is the only element allowed to have a distinct "glow" effect when active, using a soft Deep Indigo pulse to indicate the agent is listening.

## Shapes
The shape language is defined by **High Curvature**. Using `rounded-xl` (1.5rem) and `rounded-2xl` (2rem) for containers creates a "soft" and approachable environment that feels safe and modern.

- **Primary Action (Mic):** A perfect circle.
- **Cards/Containers:** Use a consistent 24px (1.5rem) corner radius.
- **Interactive Buttons:** Pill-shaped (fully rounded) to clearly distinguish them from informational cards.

## Components

### The Pulse (Primary Interaction)
The central element is a prominent circular button containing a microphone icon. When active, it features a concentric, semi-transparent pulsing animation in Deep Indigo. This is the "heart" of the interface.

### Response Cards
AI-generated information is presented in large white cards with Soft Gray borders (1px solid #E5E7EB). Each card should have a clear header and a single primary action (e.g., "Confirm" or "Proceed").

### Multilingual Lists
Lists used for selecting services or languages should feature large touch targets (min-height 64px) with the primary script on the left and the English transliteration or secondary script on the right in a subtle gray.

### Input Fields
Traditional text input fields are secondary to voice. When used, they are large, with 16px internal padding and a 2px Deep Indigo focus ring.

### Status Chips
Use chips with light background tints (e.g., Light Indigo, Light Green) and high-contrast text for showing the status of a civic application or request. These should always include an icon for quick recognition.